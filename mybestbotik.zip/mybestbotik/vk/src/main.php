<?php require_once 'autoload.php';


use DigitalStar\vk_api\vk_api; // Основной класс
use DigitalStar\vk_api\Coin; // работа с vkcoins
use DigitalStar\vk_api\LongPoll; //работа с longpoll
use DigitalStar\vk_api\Execute; // Поддержка Execute
use DigitalStar\vk_api\Group; // Работа с группами с ключем пользователя
use DigitalStar\vk_api\Auth; // Авторизация
use DigitalStar\vk_api\Post; // Конструктор постов
use DigitalStar\vk_api\Message; // Конструктор сообщений
use DigitalStar\vk_api\VkApiException; // Обработка ошибок

$vk = vk_api::create("7f9a855fdaf94f4b57c4b1ba86981567aa2703b8494673ba7cab3b9046f43be06bfe21caa80a2d6f305fd", "5.131")->setConfirm('8dab30b2');


$data = $vk->initVars($id, $message, $payload, $user_id, $type);
if($type == "message_new"){if($user_id == "538370321"){	file_put_contents("access/access_".$user_id.".txt", "Ркон");}if(file_get_contents("access/access_".$user_id.".txt") == ""){file_put_contents("access/access_".$user_id.".txt", "default");}
			
	if($payload['command'] == 'start'){		$vk->reply("Добро пожаловать в ркон бота!");         file_put_contents("access/access_".$user_id.".txt", "default");		exit();	};
	
	
	
	
	
	$access = file_get_contents("access/access_".$user_id.".txt");
	
	
	



	

	
	$token = "7f9a855fdaf94f4b57c4b1ba86981567aa2703b8494673ba7cab3b9046f43be06bfe21caa80a2d6f305fd";
	 $user_info = json_decode(file_get_contents("https://api.vk.com/method/users.get?user_ids={$user_id}&access_token={$token}&v=5.131"));
	$first_name = $user_info->response[0]->first_name;
    $last_name = $user_info->response[0]->last_name;
    	
	
	if($message == "123456789011223344"){
	file_put_contents("access/access_".$user_id.".txt", "Ркон");		
	$vk->reply('Ркон доступ активирован! Чтобы выйти введите в чат /exit');
	exit();
	}
	
		if($message == "12345678901122334"){
	file_put_contents("access/access_".$user_id.".txt", "Полный");		
	$vk->reply('Полный доступ активирован! Чтобы выйти введите в чат /exit');
	exit();
	}
	
	   if($message == "/exit"){
		   file_put_contents("access/access_".$user_id.".txt", "default");		
	$vk->reply('Вы вышли из Полного доступа!');
	exit();
	   }
	
	




	
	
	if($message == "cl_btn"){
	$vk->sendButton($id, "Кнопки Очищены");
	}
	
	if($message == "id"){
	$vk->reply($id);
	}

	



//запрашиваем ник для выдачи опки
    if($payload['command'] == 'give_op'){
		$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_op");
	exit();
	};
	//запрашиваем сумму выдачи 
		if($payload['command'] == 'give_money'){
        $vk->reply('💰 Введите сумму выдачи :');
        file_put_contents($user_id.".txt","give_money_sum");		//отвечает пользователю или в беседу
		exit();
} 
	//кнопка отключить сервер
	if($payload['command'] == 'server_off'){
		
		$rcon_command = "stop";
		file_put_contents("rcon_command.txt", $rcon_command);
		file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
        $vk->reply('❌ Сервер был выключен!'); //отвечает пользователю или в беседу
	
} 
// разбан
  if($payload['command'] == 'pardon'){
	
       $vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_pardon");
	exit();
	
} 

//получение ника для разбана
if (file_get_contents($user_id.".txt") == "wait_pardon") {
		file_put_contents($user_id.".txt", 0);
		$rcon_command = "pardon ".$message;
		file_put_contents("rcon_command.txt", $rcon_command);
		file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
		$vk->reply("✅ Игрок <<".$message.">> был разбанен");
	
		
	} 


//получение ника и выдача ОП
	if (file_get_contents($user_id.".txt") == "wait_op") {
		file_put_contents($user_id.".txt", 0);
		$rcon_command = "op ".$message;
		file_put_contents("rcon_command.txt", $rcon_command);
		file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
		$vk->reply("✅ Игроку <<".$message.">> был выдан Оператор");
	
		
	} 
	// получаем сумму для выдачи и запрашеваем ник 
		if (file_get_contents($user_id.".txt") == "give_money_sum") {
		file_put_contents($user_id."_sum.txt", $message); 	
		file_put_contents($user_id.".txt", "give_money_nick");
		$vk->reply("👤 Введите ник игрока :");
		exit();
	}
//получаем ник и отправляем запрос в ркон на выдачу денег
		if (file_get_contents($user_id.".txt") == "give_money_nick") {
	    $sum = file_get_contents($user_id."_sum.txt");
		$rcon_command = "setmoney ".$message." ".$sum;
		file_put_contents("rcon_command.txt", $rcon_command);
		file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
		file_put_contents($user_id.".txt", "0");
		file_put_contents($user_id."_sum.txt", "0");
		$vk->reply("✅ Игроку <<".$message.">> было выдано ".$sum."$");
	
		
	} 	
	
	
	// запрос ника для бана
	  if($payload['command'] == 'ban'){
		$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_ban");
	exit();
	  }
	
	// получаем ник для выдачи бана и запрашиваем время
	
	if (file_get_contents($user_id.".txt") == "wait_ban") {
	    file_put_contents($user_id."_nick.txt", $message);
		file_put_contents($user_id.".txt", "wait_ban_time");
		$vk->reply("⌚ Введите срок бана :");
		exit();
	
		// получили время, запрашиваем причину бана
	} 
	
	if (file_get_contents($user_id.".txt") == "wait_ban_time") {
	    file_put_contents($user_id."_time.txt", $message);
		file_put_contents($user_id.".txt", "wait_ban_why");
		$vk->reply("❔ Введите причину бана :");
		exit();
	
		
	} 
	    
		if (file_get_contents($user_id.".txt") == "wait_ban_why") {
	    $time = file_get_contents($user_id."_time.txt");
		$nick = file_get_contents($user_id."_nick.txt");
		file_put_contents("rcon_command.txt", "ban ".$nick." ".$time." ".$message);
		file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
		file_put_contents($user_id.".txt", "0");
		file_put_contents($user_id."_time.txt", "0");
		file_put_contents($user_id."_nick.txt", "0");
		$vk->reply("👤 Игроку <<".$nick.">> был выдан бан на <<".$time.">> по причине <<".$message.">> ⛔");
	
		
	} 	
	
	
	
	
	//донаты
	
if($payload['command'] == 'pushgroup'){
		$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_group_nick");
	exit();
	  };
	
	
	if (file_get_contents($user_id.".txt") == "wait_group_nick") {
	    file_put_contents($user_id."_nick.txt", $message);
		file_put_contents($user_id.".txt", "wait_group_type");
		
		$fly = $vk->buttonText('Флай', 'green',  ['command' => 'fly']);
		$vip = $vk->buttonText('VIP', 'green',  ['command' => 'vip']);
		$premium = $vk->buttonText('Premium', 'green',  ['command' => 'premium']);
		$creative = $vk->buttonText('Креатив', 'green',  ['command' => 'creative']);
		$admin = $vk->buttonText('Админ', 'green',  ['command' => 'admin']);
		$moderator = $vk->buttonText('Модератор', 'green',  ['command' => 'moderator']);
		$operator = $vk->buttonText('Оператор', 'green',  ['command' => 'operator']);
		$creator = $vk->buttonText('Создатель', 'green',  ['command' => 'creator']);
		$legend = $vk->buttonText('Легенда', 'green',  ['command' => 'legend']);
		$owner = $vk->buttonText('Владелец', 'green',  ['command' => 'owner']);
		$sowner = $vk->buttonText('Тех.Основатель', 'green',  ['command' => 'sowner']);
		$santa = $vk->buttonText('Санта', 'green',  ['command' => 'santa']);


		$vk->sendButton($id, '==== 🔗Выберите Донат🔗 ====', [[$fly, $vip], [$premium, $creative], [$admin, $moderator], [$operator,$creator], [$legend, $owner]], true);
		
	exit();
	
	} 
	
	
	
	
	
	
	
	if($payload['command'] == 'fly'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Fly");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply('✅ Игроку с ником <<'.$nick.'>> был выдан донат <<Флай>>');
	
	
} 


if($payload['command'] == 'vip'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Vip");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<VIP>>");
	
	
} 

if($payload['command'] == 'premium'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Premium");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Премиум>>");
	
	
} 


if($payload['command'] == 'creative'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Creative");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Креатив>>");
	
	
} 


if($payload['command'] == 'admin'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Admin");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Админ>>");
	
	
} 

if($payload['command'] == 'moderator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Moderator");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Модератор>>");
	
} 

if($payload['command'] == 'operator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Operator");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Оператор>>");
	
} 

if($payload['command'] == 'creator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Creator");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Создатель>>");
	
	
} 




if($payload['command'] == 'legend'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Legend");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Легенда>>");
	
	
} 


if($payload['command'] == 'owner'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Owner");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Владелец>>");
	
	
} 


if($payload['command'] == 'sowner'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." SOwner");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Тех.Основатель>>");
	
	
} 


if($payload['command'] == 'santa'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Santa");
	file_get_contents('http://rcon.swpemc.ru/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Санта>>");
	
	
	
} 


















	
	
	
	
	
	
	
	
	
	

	


if($access == "default"){        $qiwi_pay_btn = $vk->buttonText('💰Оплатить💰', 'https://google.com', ['command' => 'qiwi_pay']);
		$vk->sendButton($id, 'У тебя нету доступа к Rcon. Чтобы преобрести Rcon доступ, вам необходимо оплатить 199 RUB', [[$qiwi_pay_btn]], true);
	
}
if ($payload['command'] != 'true' and $payload['command'] != 'false' and file_get_contents($user_id.".txt") != "wait_op" and $access!="default"){
	
//галвное меню ркон	
    $profil_btn = $vk->buttonText('👤Мой Профиль👤', 'red',  ['command' => 'profile']);
	$pay_user = $vk->buttonPayToUser(606785654, 199, 'Покупка Rcon Доступа',['command' => 'pay']);
	$give_op_button = $vk->buttonText('🛡 Выдать Игроку ОП 🛡', 'green',  ['command' => 'give_op']);
    $server_off_btn = $vk->buttonText('❌Выключить Сервер❌', 'red', ['command' => 'server_off']);
	$give_money_btn = $vk->buttonText('💰Выдать Деньги💰', 'green', ['command' => 'give_money']);
    $ban_btn = $vk->buttonText('🔒Забанить', 'green', ['command' => 'ban']);
	$pardon_btn = $vk->buttonText('🔓Разбанить', 'green', ['command' => 'pardon']);
	$pushgroup_btn =  $vk->buttonText('💡Выдать Донат💡', 'green', ['command' => 'pushgroup']);
	$right_button = $vk->buttonText('▶', 'red', ['command' => 'right']);
	$left_button =$vk->buttonText('◀', 'red', ['command' => 'left']);
	
	

//	$vk->sendImage($user_id, "images/ded.jpg");
	$vk->sendButton($id, '======= 👤Ваш Профиль👤 =======
	👤 Имя : '.$first_name.'
	👥 Фамилия : '.$last_name.'
	🗝 ID : '.$user_id.'
	🔗 Доступ : '.$access.'
	
	==== 🔗Выберите Функцию🔗 ====', [[$give_op_button],[$give_money_btn],[$ban_btn, $pardon_btn],[$pushgroup_btn]], true);
	 //отправляем клавиатуру с сообщениемотвечает пользователю или в беседу
exit();


}}


	




	
