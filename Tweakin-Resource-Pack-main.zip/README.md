# Tweakin-Resource-Pack
Default resource pack for tweakin spigot plugin

To download the pack 
* click on green color code button
* click on download .zip option 
* after download is complete unzip the file and place the folder in your resourcepacks folder
