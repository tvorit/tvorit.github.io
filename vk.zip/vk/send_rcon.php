<?php
require_once('Rcon.php');
require_once('config.php');

            

use Thedudeguy\Rcon;

$rcon_command = file_get_contents("rcon_command.txt");
file_put_contents("log_command.txt", $rcon_command);

   

$rcon = new Rcon($host, $port, $password, $timeout);
 
if ($rcon->connect())
{
  $rcon->sendCommand($rcon_command);
  file_get_contents("https://api.vk.com/method/messages.send?message=&peer_id=606785654&access_token=7f9a855fdaf94f4b57c4b1ba86981567aa2703b8494673ba7cab3b9046f43be06bfe21caa80a2d6f305fd&v=5.131&random_id=0");
}

$data_ans = $rcon->getResponse();

file_put_contents("online.txt", $data_ans);
file_put_contents("log_command.txt", $rcon_command."      ".$data_ans);


?>