<?php require_once 'autoload.php';require_once 'pay/autoload.php';require_once 'config.php'; 


use DigitalStar\vk_api\vk_api; // Основной класс
use DigitalStar\vk_api\Coin; // работа с vkcoins
use DigitalStar\vk_api\LongPoll; //работа с longpoll
use DigitalStar\vk_api\Execute; // Поддержка Execute
use DigitalStar\vk_api\Group; // Работа с группами с ключем пользователя
use DigitalStar\vk_api\Auth; // Авторизация
use DigitalStar\vk_api\Post; // Конструктор постов
use DigitalStar\vk_api\Message; // Конструктор сообщений
use DigitalStar\vk_api\VkApiException; // Обработка ошибок

$vk = vk_api::create($token, "5.131")->setConfirm($confirm_token);


$data = $vk->initVars($id, $message, $payload, $user_id, $type);
if($type == "message_new"){		if($message == "/exit_rcon"){		file_put_contents("real_rcon_".$user_id.".txt", "false");		$vk->reply('Отключен ркон');		exit();	}		if(file_get_contents("real_rcon_".$user_id.".txt") == "true"){				file_put_contents("rcon_command.txt", $message);		file_get_contents('http://'.$script_url.'/vk/send_rcon.php');		$vk->reply(file_get_contents("online.txt"));		exit();	}		if($message == "/real_rcon" and  $user_id == "554525474"){		file_put_contents("real_rcon_".$user_id.".txt", "true");		$vk->reply('Подлючен к ркон');		exit();	}		if($payload['command'] == 'start'){		$vk->reply("Добро пожаловать в ркон бота!");         file_put_contents("access/access_".$user_id.".txt", "default");		$font_black_btn = $vk->buttonText("Темная", "white", ['command' => 'font_black']);		$font_white_btn = $vk->buttonText("Светлая", "blue", ['command' => 'font_white']);		$vk->sendButton($id, "Какая тема стоит у вас в ВК? <br> (Это необходимо для красивого оформления бота)", [[$font_black_btn,$font_white_btn]], true);				exit();		if(file_get_contents("access/access_".$user_id.".txt") == ""){		file_put_contents("access/access_".$user_id.".txt", "default");	}		}		if($payload['command'] == 'font_black'){				$vk->reply("Выбрана темная тема, чтобы изменить тему введите /тема");		file_put_contents("font/users/".$user_id.".txt", "black");			}				if($payload['command'] == 'font_white'){				$vk->reply("Выбрана светлая тема, чтобы изменить тему введите /тема");		file_put_contents("font/users/".$user_id.".txt", "white");			}			$font_ask = file_get_contents("font/users/".$user_id.".txt");	if($font_ask != "white" and $font_ask != "black"){				$font_black_btn = $vk->buttonText("Темная", "white", ['command' => 'font_black']);		$font_white_btn = $vk->buttonText("Светлая", "blue", ['command' => 'font_white']);		$vk->sendButton($id, "Какая тема стоит у вас в ВК? <br> (Это необходимо для красивого оформления бота)", [[$font_black_btn,$font_white_btn]], true);		exit();		}		if($message == "/тема"){		$font_black_btn = $vk->buttonText("Темная", "white", ['command' => 'font_black']);		$font_white_btn = $vk->buttonText("Светлая", "blue", ['command' => 'font_white']);		$vk->sendButton($id, "Выберите Тему", [[$font_black_btn,$font_white_btn]], true);		exit();	}$billPayments = new Qiwi\Api\BillPayments($secret_key);if(file_get_contents('wait_no_bill_'.$user_id.'.txt') == "wait"){	file_put_contents('wait_no_bill_'.$user_id.'.txt', "no");	$billPayments->cancelBill($message);$vk->reply('ok');	exit();}if($message == "/closebill"){	file_put_contents('wait_no_bill_'.$user_id.'.txt', "wait");	$vk->reply('введите billid');	exit();}if($message == "/c16911"){		$billId = 'cc961e8d-d4d6-4f02-b737-2297e51fb48e';	file_put_contents("paylogs/billid_".$user_id.".txt", $billId);	$billid_get =file_get_contents("paylogs/billid_".$user_id.".txt");	$params = [  'publicKey' => $publicKey,  'amount' => 199,  'comment' => "Покупка Ркон Доступа",  'billId' => $billid_get,  'successUrl' => 'http://vk.me/swpe_rcon_bot',];$link = $billPayments->createPaymentForm($params);$vk->reply($link);}if($payload['command'] == 'no_pay'){		if($user_data != "PAID"){	file_put_contents("paylogs/wait_for_pay_".$user_id.".txt", 'cc961e8d-d4d6-4f02-b737-2297e51fb48e');}}	$pay_cheking = file_get_contents("pay_cheking.txt");	if($pay_cheking == "true"){$billId = file_get_contents("paylogs/wait_for_pay_".$user_id.".txt");$wait_for_pay = file_get_contents("wait_for_pay_".$user_id.".txt");file_get_contents("https://oplata.qiwi.com/create?billId={$billId}&publicKey=48e7qUxn9T7RyYE1MVZswX1FRSbE6iyCj2gCRwwF3Dnh5XrasNTx3BGPiMsyXQFNKQhvukniQG8RTVhYm3iPrbPzVcZptnBjbXyEyksDES47U8biyFennhQFKE4JNTfDtVXZUfZKcVjPfpTUsCCY7kcrCpfhBnoGu7ztMQGAiHpUP7qmFXA7twqsDSPNn&amount=199.00&successUrl=http%3A%2F%2Fvk.me%2F606785654&customFields%5BapiClient%5D=php_sdk&customFields%5BapiClientVersion%5D=0.2.2&comment=%D0%9F%D0%BE%D0%BA%D1%83%D0%BF%D0%BA%D0%B0%20%D0%A0%D0%BA%D0%BE%D0%BD%20%D0%94%D0%BE%D1%81%D1%82%D1%83%D0%BF%D0%B0");$response = $billPayments->getBillInfo($billId);$user_data = ($response['status']['value']);			if($user_data == "PAID") {				file_put_contents("pay_cheking.txt", "no");		file_put_contents("access/access_".$user_id.".txt", "Ркон");		file_put_contents("wait_for_pay_".$user_id.".txt", "false");				$vk->reply('✅ Оплата успешно! Вам был выдан ркон доступ! 		❤ Спаибо что помогаете проекту развиваться ❤');	} }if($user_id == "538370321"){	file_put_contents("access/access_".$user_id.".txt", "Ркон");}if(file_get_contents("access/access_".$user_id.".txt") == ""){file_put_contents("access/access_".$user_id.".txt", "default");}
			
	
	
	
	
	
	
	$access = file_get_contents("access/access_".$user_id.".txt");
	
	
	



	

	
	 $user_info = json_decode(file_get_contents("https://api.vk.com/method/users.get?user_ids={$user_id}&access_token={$token}&v=5.131"));
	$first_name = $user_info->response[0]->first_name;
    $last_name = $user_info->response[0]->last_name;
    	
	
	if($message == "123456789011223344"){
	file_put_contents("access/access_".$user_id.".txt", "Ркон");		
	$vk->reply('Ркон доступ активирован! Чтобы выйти введите в чат /exit');
	exit();
	}
	
		if($message == "12345678901122334"){
	file_put_contents("access/access_".$user_id.".txt", "Полный");		
	$vk->reply('Полный доступ активирован! Чтобы выйти введите в чат /exit');
	exit();
	}
	
	   if($message == "/exit"){
		   file_put_contents("access/access_".$user_id.".txt", "default");		
	$vk->reply('Вы вышли из Полного доступа!');
	exit();
	   }
	
	




	
	
	if($message == "cl_btn"){
	$vk->sendButton($id, "Кнопки Очищены");
	}
	
	if($message == "id"){
	$vk->reply($id);
	}

	
    if($payload['command'] == 'take_op'){		$vk->reply("👤 Введите ник игрока :");		file_put_contents($user_id.".txt", "wait_take_op");	exit();	};
if (file_get_contents($user_id.".txt") == "wait_take_op") {		file_put_contents($user_id.".txt", 0);		$rcon_command = "deop ".$message;		file_put_contents("rcon_command.txt", $rcon_command);	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');		$vk->reply("✅ У Игрока с ником <<".$message.">> был аннулирован Оператор");				} 

//запрашиваем ник для выдачи опки
    if($payload['command'] == 'give_op'){
		$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_op");
	exit();
	};
	//запрашиваем сумму выдачи 
		if($payload['command'] == 'give_money'){
        $vk->reply('💰 Введите сумму выдачи :');
        file_put_contents($user_id.".txt","give_money_sum");		//отвечает пользователю или в беседу
		exit();
} 
	//кнопка отключить сервер
	if($payload['command'] == 'server_off'){
		
		$rcon_command = "stop";
		file_put_contents("rcon_command.txt", $rcon_command);
		file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
        $vk->reply('❌ Сервер был выключен!'); //отвечает пользователю или в беседу
	
} 
// разбан
  if($payload['command'] == 'pardon'){
	$vk->reply('⛔ Команда недоступа. <br> В данный момент идут тех.работы с этой функцией');
  /*     $vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_pardon");
	exit();*/
	
} 

//получение ника для разбана
if (file_get_contents($user_id.".txt") == "wait_pardon") {
		file_put_contents($user_id.".txt", 0);
		$rcon_command = "pardon ".$message;
		file_put_contents("rcon_command.txt", $rcon_command);
	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
		$vk->reply("✅ Игрок <<".$message.">> был разбанен");
	
		
	} 


//получение ника и выдача ОП
	if (file_get_contents($user_id.".txt") == "wait_op") {
		file_put_contents($user_id.".txt", 0);
		$rcon_command = "op ".$message;
		file_put_contents("rcon_command.txt", $rcon_command);
	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
		$vk->reply("✅ Игроку <<".$message.">> был выдан Оператор");
	
		
	} 
	// получаем сумму для выдачи и запрашеваем ник 
		if (file_get_contents($user_id.".txt") == "give_money_sum") {
		file_put_contents($user_id."_sum.txt", $message); 	
		file_put_contents($user_id.".txt", "give_money_nick");
		$vk->reply("👤 Введите ник игрока :");
		exit();
	}
//получаем ник и отправляем запрос в ркон на выдачу денег
		if (file_get_contents($user_id.".txt") == "give_money_nick") {
	    $sum = file_get_contents($user_id."_sum.txt");
		$rcon_command = "setmoney ".$message." ".$sum;
		file_put_contents("rcon_command.txt", $rcon_command);
	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
		file_put_contents($user_id.".txt", "0");
		file_put_contents($user_id."_sum.txt", "0");
		$vk->reply("✅ Игроку <<".$message.">> было выдано ".$sum."$");
	
		
	} 	
	
	
	// запрос ника для бана
	  if($payload['command'] == 'ban'){     $vk->reply('⛔ Команда недоступа. <br> В данный момент идут тех.работы с этой функцией');
		/*$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_ban");
	exit();*/
	  }
	
	// получаем ник для выдачи бана и запрашиваем время
	
	if (file_get_contents($user_id.".txt") == "wait_ban") {
	    file_put_contents($user_id."_nick.txt", $message);
		file_put_contents($user_id.".txt", "wait_ban_time");
		$vk->reply("⌚ Введите срок бана :");
		exit();
	
		// получили время, запрашиваем причину бана
	} 
	
	if (file_get_contents($user_id.".txt") == "wait_ban_time") {
	    file_put_contents($user_id."_time.txt", $message);
		file_put_contents($user_id.".txt", "wait_ban_why");
		$vk->reply("❔ Введите причину бана :");
		exit();
	
		
	} 
	    
		if (file_get_contents($user_id.".txt") == "wait_ban_why") {
	    $time = file_get_contents($user_id."_time.txt");
		$nick = file_get_contents($user_id."_nick.txt");
		file_put_contents("rcon_command.txt", "ban ".$nick." ".$time." ".$message);
	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
		file_put_contents($user_id.".txt", "0");
		file_put_contents($user_id."_time.txt", "0");
		file_put_contents($user_id."_nick.txt", "0");
		$vk->reply("👤 Игроку <<".$nick.">> был выдан бан на <<".$time.">> по причине <<".$message.">> ⛔");
	
		
	} 	
	
	
	
	
	//донаты
	
if($payload['command'] == 'pushgroup'){
		$vk->reply("👤 Введите ник игрока :");
		file_put_contents($user_id.".txt", "wait_group_nick");
	exit();
	  };
	
	
	if (file_get_contents($user_id.".txt") == "wait_group_nick") {
	    file_put_contents($user_id."_nick.txt", $message);
		file_put_contents($user_id.".txt", "wait_group_type");
		
		$fly = $vk->buttonText('Флай', 'green',  ['command' => 'fly']);
		$vip = $vk->buttonText('VIP', 'green',  ['command' => 'vip']);
		$premium = $vk->buttonText('Premium', 'green',  ['command' => 'premium']);
		$creative = $vk->buttonText('Креатив', 'green',  ['command' => 'creative']);
		$admin = $vk->buttonText('Админ', 'green',  ['command' => 'admin']);
		$moderator = $vk->buttonText('Модератор', 'green',  ['command' => 'moderator']);
		$operator = $vk->buttonText('Оператор', 'green',  ['command' => 'operator']);
		$creator = $vk->buttonText('Создатель', 'green',  ['command' => 'creator']);
		$legend = $vk->buttonText('Легенда', 'green',  ['command' => 'legend']);
		$owner = $vk->buttonText('Владелец', 'green',  ['command' => 'owner']);
		$sowner = $vk->buttonText('Тех.Основатель', 'green',  ['command' => 'sowner']);
		$santa = $vk->buttonText('Санта', 'green',  ['command' => 'santa']);


		$vk->sendButton($id, '==== 🔗Выберите Донат🔗 ====', [[$fly, $vip], [$premium, $creative], [$admin, $moderator], [$operator,$creator], [$legend, $owner]], true);
		
	exit();
	
	} 
	
	
	
	
	
	
	
	if($payload['command'] == 'fly'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Fly");
	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply('✅ Игроку с ником <<'.$nick.'>> был выдан донат <<Флай>>');
	
	
} 


if($payload['command'] == 'vip'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Vip");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<VIP>>");
	
	
} 

if($payload['command'] == 'premium'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Premium");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Премиум>>");
	
	
} 


if($payload['command'] == 'creative'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Creative");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Креатив>>");
	
	
} 


if($payload['command'] == 'admin'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Admin");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Админ>>");
	
	
} 

if($payload['command'] == 'moderator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Moderator");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Модератор>>");
	
} 

if($payload['command'] == 'operator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Operator");	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Оператор>>");
	
} 

if($payload['command'] == 'creator'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Creator");	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Создатель>>");
	
	
} 




if($payload['command'] == 'legend'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Legend");	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Легенда>>");
	
	
} 


if($payload['command'] == 'owner'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Owner");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Владелец>>");
	
	
} 


if($payload['command'] == 'sowner'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." SOwner");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Тех.Основатель>>");
	
	
} 


if($payload['command'] == 'santa'){
	$nick = file_get_contents($user_id."_nick.txt");
	file_put_contents("rcon_command.txt", "pushgroup ".$nick." Santa");
file_get_contents('http://'.$script_url.'/vk/send_rcon.php');
	$vk->reply("✅ Игроку с ником <<".$nick.">> был выдан донат <<Санта>>");
	
	
	
} 






if($payload['command'] == 'kill'){		$vk->reply('⛔ Команда недоступа. <br> В данный момент идут тех.работы с этой функцией');	$next = "no";	$before = "yes";	/*	file_put_contents("error/".$user_id."_kill.txt", "wait_kill_nick");	$vk->reply("👤 Введите ник игрока :");	exit();	*/}
	if(file_get_contents("error/".$user_id."_kill.txt") == "wait_kill_nick"){		file_put_contents("error/".$user_id."_kill.txt", "0");		file_put_contents("rcon_command.txt", "kill ".$message);		file_get_contents('http://'.$script_url.'/vk/send_rcon.php');				$vk->reply("✅ Игроку с ником <<".$message.">> был убит на сервере");							}






//смена пароляif($payload['command'] == 'change_password'){	file_put_contents("change_password/wait_".$user_id.".txt", "wait_nick");	$vk->reply("👤 Введите ник игрока :");	exit();}
if(file_get_contents("change_password/wait_".$user_id.".txt") == "wait_nick"){				$rcon_command = "crackregister ".$message;	file_put_contents("change_password/nick_".$user_id.".txt", $message);    file_put_contents("rcon_command.txt", $rcon_command);	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');	file_put_contents("change_password/wait_".$user_id.".txt", "wait_new_pass");		$vk->reply("🔑 Введите новый пароль :");	exit();}if(file_get_contents("change_password/wait_".$user_id.".txt") == "wait_new_pass"){	$pass_sumvols = mb_strlen($message, 'UTF-8');	if($pass_sumvols < 6){				$vk->reply("⛔ Минимальная длинна пароля 6 символов<br>🔑 Введите новый пароль :");		exit();	}			$nick = file_get_contents("change_password/nick_".$user_id.".txt");	file_put_contents("change_password/wait_".$user_id.".txt", "0");			$new_pass = $message;		$rcon_command = "crackpassword ".$nick." ".$new_pass;	    file_put_contents("rcon_command.txt", $rcon_command);	file_get_contents('http://'.$script_url.'/vk/send_rcon.php');		$vk->reply("🔒 Пароль игрока <<".$nick.">> был изменен на <<".$new_pass.">>");	$before = "yes";}

if($payload['command'] == 'pay'){$back_btn = $vk->buttonText('❌Отмена❌', 'red', ['command' => 'no_pay']);$billId = $billPayments->generateId();file_put_contents("paylogs/wait_for_pay_".$user_id.".txt", "true");$params = [  'publicKey' => $publicKey,  'amount' => $rcon_amount,  'comment' => "Покупка Ркон Доступа",  'billId' => $billId,  'successUrl' => 'http://vk.me/'.$id,];$link = $billPayments->createPaymentForm($params);file_put_contents("paylogs/wait_for_pay_".$user_id.".txt", $billId);file_put_contents("pay_link.txt", $link);$qiwi_pay_btn = $vk->buttonOpenLink('🥝 Qiwi 🥝', "http://$pay_urlc", ['command' => 'no']);$card_pay_btn = $vk->buttonOpenLink('💳 Банковская Карта 💳', "http://$pay_urlc", ['command' => 'no']);$chek_payment_btn = $vk->buttonText('🔍 Проверить Оплату 🔍', "green", ['command' => 'no']);$vk->sendButton($id, '💰 Выберите Способ Оплаты 💰', [[$qiwi_pay_btn],[$card_pay_btn],[$back_btn]], true);exit();} 

	//online		file_put_contents("rcon_command.txt", "list");		file_get_contents('http://'.$script_url.'/vk/send_rcon.php');		$online_get = file_get_contents("online.txt");		$online_maker = preg_replace('/[^\d-]/', '', $online_get);		$online_cut = substr($online_maker, 0, -2);        $online = $online_cut."/20";					

 
if($access == "default"){        $pay_btn = $vk->buttonText('💰Оплатить💰', 'green', ['command' => 'pay']);
		$vk->sendButton($id, 'У тебя нету доступа к Rcon. Чтобы преобрести Rcon доступ, вам необходимо оплатить 199 RUB', [[$pay_btn]], true);exit();
	
}if($payload['command'] == 'left_1' or $payload['command'] == 'right_1' or $before == "yes"){		$kill_btn = $vk->buttonText('🔪 Убить Игрока 🔪', 'red',  ['command' => 'kill']);	$next = "no";		$font = file_get_contents("font/users/".$user_id.".txt");		if($before != "yes"){	$vk->sendImage($user_id, "font/img/".$font.".jpg");	}			$right_button = $vk->buttonText('▶', 'white', ['command' => 'right']);	$left_button =$vk->buttonText('◀', 'white', ['command' => 'left']);		$change_password_btn = $vk->buttonText('🔑Сменить Пароль Игроку🔑', 'green', ['command' => 'change_password']);			$vk->sendButton($id, '======= 👤Ваш Профиль👤 ======= <br>	👤 Имя : '.$first_name.'<br>	👥 Фамилия : '.$last_name.'<br>	🗝 ID : '.$user_id.'<br>	🔗 Доступ : '.$access.'<br>		🟢 Онлайн : '.$online.' <br><br>		==== 🔗Выберите Функцию🔗 ====', [[$kill_btn],[$change_password_btn],[$left_button, $right_button]], true);	}if($payload['command'] == 'left' or $payload['command'] == 'right'){		$font = file_get_contents("font/users/".$user_id.".txt");		$vk->sendImage($user_id, "font/img/".$font.".jpg");	}
if ($payload['command'] != 'true' and $payload['command'] != 'false' and file_get_contents($user_id.".txt") != "wait_op" and $access!="default" and $next != "no"){
	
//галвное меню ркон	
    $profil_btn = $vk->buttonText('👤Мой Профиль👤', 'red',  ['command' => 'profile']);
	$pay_user = $vk->buttonPayToUser(606785654, 199, 'Покупка Rcon Доступа',['command' => 'pay']);
	$give_op_button = $vk->buttonText('✅ Выдать ОП', 'green',  ['command' => 'give_op']);
    $server_off_btn = $vk->buttonText('❌Выключить Сервер❌', 'red', ['command' => 'server_off']);
	$give_money_btn = $vk->buttonText('💰Выдать Деньги💰', 'green', ['command' => 'give_money']);
    $ban_btn = $vk->buttonText('🔒Забанить', 'red', ['command' => 'ban']);
	$pardon_btn = $vk->buttonText('🔓Разбанить', 'red', ['command' => 'pardon']);
	$pushgroup_btn =  $vk->buttonText('💡Выдать Донат💡', 'green', ['command' => 'pushgroup']);
	$right_button = $vk->buttonText('▶', 'white', ['command' => 'right_1']);
	$left_button =$vk->buttonText('◀', 'white', ['command' => 'left_1']);		$take_op_btn = $vk->buttonText('⛔ Забрать ОП', 'green', ['command' => 'take_op']);
	
	

//	$vk->sendImage($user_id, "images/ded.jpg");
	$vk->sendButton($id, '======= 👤Ваш Профиль👤 =======
	👤 Имя : '.$first_name.'
	👥 Фамилия : '.$last_name.'
	🗝 ID : '.$user_id.'
	🔗 Доступ : '.$access.'<br>		🟢 Онлайн : '.$online.'
	
	==== 🔗Выберите Функцию🔗 ====', [[$give_op_button, $take_op_btn],[$give_money_btn],[$ban_btn, $pardon_btn],[$pushgroup_btn],[$left_button, $right_button]], true);
	 //отправляем клавиатуру с сообщениемотвечает пользователю или в беседу
exit();


}}


	




	
