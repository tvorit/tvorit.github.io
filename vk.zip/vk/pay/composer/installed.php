<?php return array(
    'root' => array(
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => NULL,
        'name' => '__root__',
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => NULL,
            'dev_requirement' => false,
        ),
        'qiwi/bill-payments-php-sdk' => array(
            'pretty_version' => '0.2.2',
            'version' => '0.2.2.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../qiwi/bill-payments-php-sdk',
            'aliases' => array(),
            'reference' => 'b9deaea7c916dc7282779f01b821a3082504529d',
            'dev_requirement' => false,
        ),
    ),
);
